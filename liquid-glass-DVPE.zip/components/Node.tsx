import React from 'react';
import { Node as NodeType, Port } from '../types';
import { INITIAL_NODES, THEME_COLORS as COLORS } from '../constants';
import Knob from './Knob';

interface NodeProps {
  node: NodeType;
  isSelected: boolean;
  onMouseDown: (e: React.MouseEvent, id: string) => void;
  onPortMouseDown: (e: React.MouseEvent, nodeId: string, portId: string, isInput: boolean) => void;
  scale: number;
}

const NodeComponent: React.FC<NodeProps> = ({ 
  node, 
  isSelected, 
  onMouseDown, 
  onPortMouseDown,
  scale
}) => {
  const theme = COLORS[node.type] || COLORS.IO;

  return (
    <div
      className={`absolute node-glass rounded-2xl flex flex-col min-w-[180px]
        ${theme.border} ${isSelected ? 'ring-2 ring-white/40 z-20' : 'z-10'}
      `}
      style={{
        left: node.x,
        top: node.y,
      }}
    >
      {/* Header */}
      <div 
        className={`
          h-10 rounded-t-2xl bg-gradient-to-r ${theme.header} 
          flex items-center justify-between px-3 cursor-grab active:cursor-grabbing border-b border-white/5
        `}
        onMouseDown={(e) => onMouseDown(e, node.id)}
      >
        <span className={`font-semibold text-xs tracking-wider uppercase ${theme.text} drop-shadow-md`}>
          {node.data.label}
        </span>
        <div className="flex gap-1.5">
          <div className={`w-2 h-2 rounded-full ${theme.port} shadow-[0_0_5px_currentColor] opacity-80`} />
        </div>
      </div>

      {/* Body */}
      <div className="p-3 flex flex-col gap-4 relative">
        
        <div className="flex justify-between w-full relative z-10">
          {/* Inputs Column */}
          <div className="flex flex-col gap-3 -ml-4 mt-1">
            {node.data.inputs.map((port) => (
              <div 
                key={port.id} 
                className="flex items-center group relative cursor-crosshair"
                onMouseDown={(e) => onPortMouseDown(e, node.id, port.id, true)}
                title={port.label}
              >
                <div className={`
                  w-3 h-3 rounded-full border border-white/30 bg-[#1a1a20] 
                  group-hover:bg-white group-hover:scale-125 transition-all
                  shadow-inner
                `} />
                <span className="ml-2 text-[9px] text-gray-400 font-mono tracking-tight group-hover:text-white transition-colors">
                  {port.label}
                </span>
              </div>
            ))}
          </div>

          {/* Outputs Column */}
          <div className="flex flex-col gap-3 -mr-4 mt-1 items-end">
            {node.data.outputs.map((port) => (
              <div 
                key={port.id} 
                className="flex items-center group relative cursor-crosshair flex-row-reverse"
                onMouseDown={(e) => onPortMouseDown(e, node.id, port.id, false)}
                title={port.label}
              >
                <div className={`
                  w-3 h-3 rounded-full border border-white/30 bg-[#1a1a20] 
                  group-hover:bg-white group-hover:scale-125 transition-all
                  shadow-inner
                `} />
                <span className="mr-2 text-[9px] text-gray-400 font-mono tracking-tight group-hover:text-white transition-colors">
                  {port.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Controls Area */}
        {node.data.controls && node.data.controls.length > 0 && (
          <div className="bg-black/20 rounded-xl p-3 border border-white/5 flex flex-wrap justify-center gap-3">
            {node.data.controls.map((ctrl, i) => (
              <Knob 
                key={i} 
                label={ctrl.label} 
                value={ctrl.value} 
                unit={ctrl.unit}
                colorClass={theme.text}
              />
            ))}
          </div>
        )}
      </div>
      
      {/* Decorative Shine */}
      <div className="absolute top-0 left-0 w-full h-full rounded-2xl pointer-events-none bg-gradient-to-br from-white/5 to-transparent opacity-50" />
    </div>
  );
};

export default NodeComponent;