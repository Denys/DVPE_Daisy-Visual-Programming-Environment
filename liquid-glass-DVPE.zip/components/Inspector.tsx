import React from 'react';
import { Node } from '../types';
import { THEME_COLORS as COLORS } from '../constants';
import Knob from './Knob';

interface InspectorProps {
  selectedNode: Node | null;
}

const Inspector: React.FC<InspectorProps> = ({ selectedNode }) => {
  if (!selectedNode) {
    return (
      <div className="w-80 glass-panel border-l border-white/10 flex flex-col items-center justify-center text-gray-500 z-30 h-full p-8 text-center">
        <div className="w-16 h-16 rounded-full bg-white/5 mb-4 flex items-center justify-center">
           <svg className="w-8 h-8 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        </div>
        <p>Select a module to inspect its properties and connections.</p>
      </div>
    );
  }

  const theme = COLORS[selectedNode.type] || COLORS.IO;

  return (
    <div className="w-80 glass-panel border-l border-white/10 flex flex-col z-30 h-full overflow-y-auto">
      {/* Header */}
      <div className="p-5 border-b border-white/10">
        <div className="text-[10px] uppercase tracking-widest text-gray-500 mb-1">Module</div>
        <div className="flex items-center justify-between">
           <h2 className={`text-2xl font-bold ${theme.text} drop-shadow`}>{selectedNode.data.label}</h2>
           <button className="text-gray-500 hover:text-white transition-colors">
             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
           </button>
        </div>
        <div className="mt-2 text-xs font-mono text-gray-400 bg-black/20 px-2 py-1 rounded inline-block border border-white/5">
           ID: {selectedNode.id}
        </div>
      </div>

      {/* Main Controls */}
      <div className="p-5 border-b border-white/10">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold text-gray-300">Parameters</span>
          <span className="text-xs text-gray-500 cursor-pointer hover:text-white">Reset All</span>
        </div>
        
        {selectedNode.data.controls ? (
          <div className="grid grid-cols-2 gap-y-6 gap-x-4">
             {selectedNode.data.controls.map((ctrl, i) => (
               <div key={i} className="flex flex-col items-center p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors border border-white/5">
                 <Knob 
                   value={ctrl.value} 
                   label={ctrl.label} 
                   unit={ctrl.unit} 
                   size={64}
                   colorClass={theme.text}
                 />
                 <div className="mt-3 flex items-center justify-between w-full px-1">
                    <span className="text-[10px] text-gray-500">CV</span>
                    <div className={`w-3 h-3 rounded border border-gray-600 bg-transparent cursor-pointer ${i===0 ? 'bg-cyan-500/50 border-cyan-500' : ''}`}></div>
                 </div>
               </div>
             ))}
          </div>
        ) : (
          <div className="text-sm text-gray-500 italic">No parameters available</div>
        )}
      </div>

      {/* Connectivity */}
      <div className="p-5 flex-1">
        <span className="text-sm font-semibold text-gray-300 block mb-3">Connectivity</span>
        
        <div className="space-y-4">
           <div>
              <div className="text-[10px] uppercase text-gray-500 mb-2 font-bold tracking-wider">Inputs</div>
              <div className="space-y-1">
                {selectedNode.data.inputs.length > 0 ? selectedNode.data.inputs.map(p => (
                  <div key={p.id} className="flex items-center justify-between text-xs p-2 rounded bg-white/5 hover:bg-white/10 transition">
                     <span className="text-gray-300 font-mono">● {p.label}</span>
                     <span className="text-gray-600 italic">Connected</span>
                  </div>
                )) : <div className="text-xs text-gray-600 pl-2">None</div>}
              </div>
           </div>

           <div>
              <div className="text-[10px] uppercase text-gray-500 mb-2 font-bold tracking-wider">Outputs</div>
              <div className="space-y-1">
                {selectedNode.data.outputs.length > 0 ? selectedNode.data.outputs.map(p => (
                  <div key={p.id} className="flex items-center justify-between text-xs p-2 rounded bg-white/5 hover:bg-white/10 transition">
                     <span className="text-gray-300 font-mono">● {p.label}</span>
                     <span className="text-gray-600 italic">→ 2 dests</span>
                  </div>
                )) : <div className="text-xs text-gray-600 pl-2">None</div>}
              </div>
           </div>
        </div>
      </div>
      
      {/* Footer Docs */}
      <div className="p-4 bg-black/20 border-t border-white/10">
         <div className="flex items-center gap-2 text-gray-400 mb-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span className="text-xs font-bold uppercase">Documentation</span>
         </div>
         <p className="text-[11px] leading-relaxed text-gray-500">
           The {selectedNode.data.label} provides standard voltage controlled signal processing. 
           Connect CV inputs to modulate parameters dynamically.
         </p>
      </div>
    </div>
  );
};

export default Inspector;