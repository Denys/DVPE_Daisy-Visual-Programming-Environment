import React from 'react';
import { NodeType } from '../types';

const Sidebar = () => {
  const modules = [
    { type: NodeType.IO, label: 'Audio Input', icon: '🎤' },
    { type: NodeType.IO, label: 'Audio Output', icon: '🔊' },
    { type: NodeType.IO, label: 'MIDI Note', icon: '🎹' },
    { type: NodeType.OSCILLATOR, label: 'Oscillator', icon: '〰️' },
    { type: NodeType.FILTER, label: 'Filter', icon: '⑁' },
    { type: NodeType.ENVELOPE, label: 'ADSR', icon: '📈' },
    { type: NodeType.MIXER, label: 'Mixer', icon: '🎚️' },
    { type: NodeType.LOGIC, label: 'Sequencer', icon: '📅' },
  ];

  return (
    <div className="w-64 glass-panel border-r border-white/10 flex flex-col z-30 h-full">
      <div className="p-4 border-b border-white/10">
        <h1 className="text-xl font-bold text-white tracking-wide bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
          Modules
        </h1>
        <div className="mt-4 relative">
          <input 
            type="text" 
            placeholder="Search modules..." 
            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-cyan-500/50"
          />
          <svg className="w-4 h-4 text-gray-500 absolute right-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {modules.map((mod, i) => (
          <div 
            key={i}
            className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/10 cursor-grab active:cursor-grabbing transition-all group"
            draggable
            onDragStart={(e) => {
              e.dataTransfer.setData('nodeType', mod.type);
            }}
          >
            <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-lg shadow-inner group-hover:bg-cyan-500/20 group-hover:text-cyan-200 transition-colors">
              {mod.icon}
            </div>
            <div className="flex flex-col">
               <span className="text-sm font-medium text-gray-200 group-hover:text-white">{mod.label}</span>
               <span className="text-[10px] text-gray-500">{mod.type}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="p-4 border-t border-white/10">
         <div className="flex items-center justify-between text-xs text-gray-500">
            <span>User I/O</span>
            <span className="bg-white/10 px-1.5 py-0.5 rounded text-[10px]">14</span>
         </div>
      </div>
    </div>
  );
};

export default Sidebar;
