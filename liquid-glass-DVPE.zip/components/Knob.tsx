import React, { useState, useEffect, useRef } from 'react';

interface KnobProps {
  value: number;
  min?: number;
  max?: number;
  label: string;
  unit?: string;
  size?: number;
  colorClass?: string;
  onChange?: (val: number) => void;
}

const Knob: React.FC<KnobProps> = ({ 
  value, 
  min = 0, 
  max = 100, 
  label, 
  unit = '', 
  size = 48,
  colorClass = 'text-cyan-400',
  onChange 
}) => {
  const [internalValue, setInternalValue] = useState(value);
  const [isDragging, setIsDragging] = useState(false);
  const startYRef = useRef<number>(0);
  const startValRef = useRef<number>(0);

  useEffect(() => {
    setInternalValue(value);
  }, [value]);

  const percentage = (internalValue - min) / (max - min);
  const angle = percentage * 270 - 135; // -135 to 135 degrees

  // SVG calculations
  const radius = size / 2 - 4;
  const center = size / 2;
  const circumference = 2 * Math.PI * radius;
  // We only show ~75% of the circle (270 degrees)
  const strokeDasharray = circumference;
  const strokeDashoffset = circumference - (percentage * 0.75) * circumference;
  
  // Rotate the track to start at bottom left (-135deg)
  // But CSS rotate is easier for the whole group

  const handleMouseDown = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsDragging(true);
    startYRef.current = e.clientY;
    startValRef.current = internalValue;
    
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  const handleMouseMove = (e: MouseEvent) => {
    const deltaY = startYRef.current - e.clientY;
    // Sensitivity: 200px drag = full range
    const range = max - min;
    const change = (deltaY / 200) * range;
    
    let newValue = startValRef.current + change;
    newValue = Math.max(min, Math.min(max, newValue));
    
    setInternalValue(newValue);
    if (onChange) onChange(newValue);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    window.removeEventListener('mousemove', handleMouseMove);
    window.removeEventListener('mouseup', handleMouseUp);
  };

  return (
    <div className="flex flex-col items-center justify-center gap-1 select-none">
      <div 
        className="relative cursor-ns-resize group"
        style={{ width: size, height: size }}
        onMouseDown={handleMouseDown}
      >
        {/* Background track */}
        <svg width={size} height={size} className="overflow-visible">
          <defs>
             <linearGradient id={`grad-${label}`} x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="currentColor" stopOpacity="0.1" />
                <stop offset="100%" stopColor="currentColor" stopOpacity="0.8" />
             </linearGradient>
             <filter id="glow-knob" x="-50%" y="-50%" width="200%" height="200%">
               <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
               <feMerge>
                   <feMergeNode in="coloredBlur"/>
                   <feMergeNode in="SourceGraphic"/>
               </feMerge>
             </filter>
          </defs>
          
          {/* Base Circle Track */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="none"
            stroke="rgba(255,255,255,0.1)"
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray={`${circumference * 0.75} ${circumference * 0.25}`}
            transform={`rotate(135 ${center} ${center})`}
          />

          {/* Value Arc */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="none"
            stroke={`url(#grad-${label})`}
            className={`${colorClass} transition-all duration-75`}
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset + (circumference * 0.25)} // Offset to match track start
            transform={`rotate(135 ${center} ${center})`}
            filter="url(#glow-knob)"
          />
        </svg>
        
        {/* Indicator Dot (Optional - rotates) */}
        <div 
           className="absolute top-0 left-0 w-full h-full pointer-events-none"
           style={{ transform: `rotate(${angle}deg)` }}
        >
          <div 
            className={`absolute top-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)]`}
          />
        </div>
      </div>
      
      <div className="text-center">
        <div className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">{label}</div>
        <div className={`text-[10px] font-mono ${isDragging ? 'text-white' : 'text-gray-500'}`}>
          {internalValue.toFixed(unit ? 1 : 2)}{unit}
        </div>
      </div>
    </div>
  );
};

export default Knob;
