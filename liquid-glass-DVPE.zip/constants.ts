import { NodeType, Node, Connection } from './types';

export const INITIAL_NODES: Node[] = [
  {
    id: 'n1',
    type: NodeType.IO,
    x: 50,
    y: 50,
    data: {
      label: 'MIDI NOTE',
      inputs: [],
      outputs: [
        { id: 'pitch', label: 'PITCH', type: 'output' },
        { id: 'vel', label: 'VEL', type: 'output' },
        { id: 'gate', label: 'GATE', type: 'output' },
      ],
      controls: [{ type: 'knob', label: 'Chan', value: 1, unit: '' }]
    }
  },
  {
    id: 'n2',
    type: NodeType.OSCILLATOR,
    x: 400,
    y: 50,
    data: {
      label: 'OSCILLATOR',
      inputs: [
        { id: 'freq_cv', label: 'FREQ CV', type: 'input' },
        { id: 'amp_cv', label: 'AMP CV', type: 'input' },
      ],
      outputs: [
        { id: 'out', label: 'OUT', type: 'output' }
      ],
      controls: [
        { type: 'knob', label: 'Freq', value: 440, unit: 'Hz' },
        { type: 'knob', label: 'Ampl', value: 0.8, unit: '' }
      ]
    }
  },
  {
    id: 'n3',
    type: NodeType.OSCILLATOR,
    x: 400,
    y: 320,
    data: {
      label: 'LFO',
      inputs: [
        { id: 'freq_cv', label: 'FREQ CV', type: 'input' },
      ],
      outputs: [
        { id: 'out', label: 'OUT', type: 'output' }
      ],
      controls: [
        { type: 'knob', label: 'Rate', value: 2, unit: 'Hz' },
        { type: 'knob', label: 'Amt', value: 0.5, unit: '' }
      ]
    }
  },
  {
    id: 'n4',
    type: NodeType.FILTER,
    x: 750,
    y: 100,
    data: {
      label: 'MOOG LADDER',
      inputs: [
        { id: 'in', label: 'IN', type: 'input' },
        { id: 'cutoff_cv', label: 'FREQ CV', type: 'input' },
      ],
      outputs: [
        { id: 'out', label: 'OUT', type: 'output' }
      ],
      controls: [
        { type: 'knob', label: 'Cutoff', value: 1200, unit: 'Hz' },
        { type: 'knob', label: 'Reso', value: 0.4, unit: '' }
      ]
    }
  },
  {
    id: 'n5',
    type: NodeType.ENVELOPE,
    x: 400,
    y: 550,
    data: {
      label: 'ADSR',
      inputs: [
        { id: 'gate', label: 'GATE', type: 'input' },
      ],
      outputs: [
        { id: 'out', label: 'OUT', type: 'output' }
      ],
      controls: [
        { type: 'knob', label: 'Att', value: 0.1, unit: 's' },
        { type: 'knob', label: 'Dec', value: 0.4, unit: 's' }
      ]
    }
  },
  {
    id: 'n6',
    type: NodeType.IO,
    x: 1100,
    y: 200,
    data: {
      label: 'AUDIO OUTPUT',
      inputs: [
        { id: 'left', label: 'L', type: 'input' },
        { id: 'right', label: 'R', type: 'input' },
      ],
      outputs: [],
      controls: [
        { type: 'knob', label: 'Gain', value: 1.0, unit: '' }
      ]
    }
  }
];

export const INITIAL_CONNECTIONS: Connection[] = [
  { id: 'c1', fromNodeId: 'n1', fromPortId: 'pitch', toNodeId: 'n2', toPortId: 'freq_cv' },
  { id: 'c2', fromNodeId: 'n2', fromPortId: 'out', toNodeId: 'n4', toPortId: 'in' },
  { id: 'c3', fromNodeId: 'n4', fromPortId: 'out', toNodeId: 'n6', toPortId: 'left' },
  { id: 'c4', fromNodeId: 'n4', fromPortId: 'out', toNodeId: 'n6', toPortId: 'right' },
  { id: 'c5', fromNodeId: 'n1', fromPortId: 'gate', toNodeId: 'n5', toPortId: 'gate' },
  { id: 'c6', fromNodeId: 'n3', fromPortId: 'out', toNodeId: 'n4', toPortId: 'cutoff_cv' },
];

export const THEME_COLORS = {
  [NodeType.IO]: {
    border: 'border-emerald-500/30',
    glow: 'shadow-emerald-500/20',
    header: 'from-emerald-900/40 to-emerald-800/20',
    port: 'bg-emerald-400',
    text: 'text-emerald-200'
  },
  [NodeType.OSCILLATOR]: {
    border: 'border-cyan-500/30',
    glow: 'shadow-cyan-500/20',
    header: 'from-cyan-900/40 to-cyan-800/20',
    port: 'bg-cyan-400',
    text: 'text-cyan-200'
  },
  [NodeType.FILTER]: {
    border: 'border-blue-500/30',
    glow: 'shadow-blue-500/20',
    header: 'from-blue-900/40 to-blue-800/20',
    port: 'bg-blue-400',
    text: 'text-blue-200'
  },
  [NodeType.ENVELOPE]: {
    border: 'border-amber-500/30',
    glow: 'shadow-amber-500/20',
    header: 'from-amber-900/40 to-amber-800/20',
    port: 'bg-amber-400',
    text: 'text-amber-200'
  },
  [NodeType.MIXER]: {
    border: 'border-fuchsia-500/30',
    glow: 'shadow-fuchsia-500/20',
    header: 'from-fuchsia-900/40 to-fuchsia-800/20',
    port: 'bg-fuchsia-400',
    text: 'text-fuchsia-200'
  },
  [NodeType.LOGIC]: {
    border: 'border-violet-500/30',
    glow: 'shadow-violet-500/20',
    header: 'from-violet-900/40 to-violet-800/20',
    port: 'bg-violet-400',
    text: 'text-violet-200'
  },
};
