export enum NodeType {
  IO = 'IO',
  OSCILLATOR = 'OSCILLATOR',
  FILTER = 'FILTER',
  ENVELOPE = 'ENVELOPE',
  MIXER = 'MIXER',
  LOGIC = 'LOGIC'
}

export interface Port {
  id: string;
  label: string;
  type: 'input' | 'output';
}

export interface NodeData {
  label: string;
  inputs: Port[];
  outputs: Port[];
  controls?: {
    type: 'knob' | 'slider' | 'switch';
    label: string;
    value: number;
    unit?: string;
  }[];
}

export interface Node {
  id: string;
  type: NodeType;
  x: number;
  y: number;
  data: NodeData;
}

export interface Connection {
  id: string;
  fromNodeId: string;
  fromPortId: string;
  toNodeId: string;
  toPortId: string;
}

export interface DragState {
  isDragging: boolean;
  nodeId: string | null;
  startX: number;
  startY: number;
  initialNodeX: number;
  initialNodeY: number;
}

export interface DragConnectionState {
  isDragging: boolean;
  fromNodeId: string | null;
  fromPortId: string | null;
  currentX: number;
  currentY: number;
}
