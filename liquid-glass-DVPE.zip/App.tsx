import React, { useState, useRef, useEffect, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import Inspector from './components/Inspector';
import NodeComponent from './components/Node';
import { INITIAL_NODES, INITIAL_CONNECTIONS } from './constants';
import { Node, Connection, DragState, DragConnectionState } from './types';

function App() {
  const [nodes, setNodes] = useState<Node[]>(INITIAL_NODES);
  const [connections, setConnections] = useState<Connection[]>(INITIAL_CONNECTIONS);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  
  // Dragging Nodes
  const [dragState, setDragState] = useState<DragState>({
    isDragging: false,
    nodeId: null,
    startX: 0,
    startY: 0,
    initialNodeX: 0,
    initialNodeY: 0
  });

  // Creating Connections
  const [connectionDrag, setConnectionDrag] = useState<DragConnectionState>({
    isDragging: false,
    fromNodeId: null,
    fromPortId: null,
    currentX: 0,
    currentY: 0
  });

  const canvasRef = useRef<HTMLDivElement>(null);

  // --- Handlers ---

  const handleNodeMouseDown = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const node = nodes.find(n => n.id === id);
    if (!node) return;

    setSelectedNodeId(id);
    setDragState({
      isDragging: true,
      nodeId: id,
      startX: e.clientX,
      startY: e.clientY,
      initialNodeX: node.x,
      initialNodeY: node.y
    });
  };

  const handlePortMouseDown = (e: React.MouseEvent, nodeId: string, portId: string, isInput: boolean) => {
    e.stopPropagation();
    // Only drag from outputs for now to simplify
    if (isInput) return;

    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    setConnectionDrag({
      isDragging: true,
      fromNodeId: nodeId,
      fromPortId: portId,
      currentX: e.clientX - rect.left,
      currentY: e.clientY - rect.top
    });
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    if (dragState.isDragging && dragState.nodeId) {
      const dx = e.clientX - dragState.startX;
      const dy = e.clientY - dragState.startY;

      setNodes(prev => prev.map(n => {
        if (n.id === dragState.nodeId) {
          return {
            ...n,
            x: dragState.initialNodeX + dx,
            y: dragState.initialNodeY + dy
          };
        }
        return n;
      }));
    }

    if (connectionDrag.isDragging) {
      setConnectionDrag(prev => ({
        ...prev,
        currentX: e.clientX - rect.left,
        currentY: e.clientY - rect.top
      }));
    }
  }, [dragState, connectionDrag.isDragging]);

  const handleMouseUp = useCallback(() => {
    if (dragState.isDragging) {
      setDragState(prev => ({ ...prev, isDragging: false, nodeId: null }));
    }
    if (connectionDrag.isDragging) {
      // Logic to snap to input port would go here. 
      // For now, just cancel.
      setConnectionDrag(prev => ({ ...prev, isDragging: false, fromNodeId: null }));
    }
  }, [dragState.isDragging, connectionDrag.isDragging]);

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  // --- SVG Path Calculation ---
  
  const getPortPosition = (node: Node, portId: string, isInput: boolean) => {
    // Approximate positions based on node layout logic in Node.tsx
    // Header is 40px height. Body padding 12px. Input row starts around 52px.
    // Each input/output row is ~24px height + 12px gap.
    
    // Find index of port
    const portIndex = isInput 
      ? node.data.inputs.findIndex(p => p.id === portId)
      : node.data.outputs.findIndex(p => p.id === portId);
    
    // Y offset calculation (approximate match to CSS)
    const headerHeight = 40;
    const padding = 12;
    const rowHeight = 24; 
    const gap = 12;
    const yOffset = headerHeight + padding + (portIndex * (rowHeight + gap)) + rowHeight/2;

    // X offset
    const xOffset = isInput ? 10 : 170; // Node width ~180

    return {
      x: node.x + xOffset,
      y: node.y + yOffset
    };
  };

  const generatePath = (x1: number, y1: number, x2: number, y2: number) => {
    const dist = Math.abs(x2 - x1);
    const controlOffset = Math.max(dist * 0.5, 50);
    return `M ${x1} ${y1} C ${x1 + controlOffset} ${y1}, ${x2 - controlOffset} ${y2}, ${x2} ${y2}`;
  };

  return (
    <div className="flex h-screen w-screen text-white mesh-bg overflow-hidden relative">
      {/* Top Bar (Overlay) */}
      <div className="absolute top-0 left-64 right-80 h-14 z-40 flex items-center justify-between px-6 pointer-events-none">
         <div className="flex items-center gap-4 pointer-events-auto">
            <span className="text-gray-400 font-mono text-xs">DVPE • Untitled Patch</span>
            <button className="bg-white/10 hover:bg-white/20 p-1.5 rounded-md text-gray-300 transition"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path></svg></button>
            <button className="bg-white/10 hover:bg-white/20 p-1.5 rounded-md text-gray-300 transition"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v1M5 19h14a2 2 0 002-2v-5a2 2 0 00-2-2H9a2 2 0 00-2 2v5a2 2 0 01-2 2z"></path></svg></button>
         </div>
         <div className="flex items-center gap-3 pointer-events-auto">
            <button className="px-3 py-1.5 rounded bg-black/40 border border-white/10 text-xs font-mono text-gray-400 hover:text-white transition">Hardware</button>
            <button className="px-3 py-1.5 rounded bg-cyan-500/20 border border-cyan-500/50 text-xs font-mono text-cyan-300 hover:bg-cyan-500/30 transition shadow-[0_0_10px_rgba(6,182,212,0.3)]">Export C++</button>
         </div>
      </div>

      <Sidebar />
      
      {/* Canvas */}
      <div 
        ref={canvasRef}
        className="flex-1 relative overflow-hidden cursor-dot"
        onMouseDown={() => setSelectedNodeId(null)}
      >
        {/* Grid Background */}
        <div className="absolute inset-0 opacity-20 pointer-events-none" 
             style={{ 
               backgroundImage: 'radial-gradient(circle, #ffffff 1px, transparent 1px)', 
               backgroundSize: '40px 40px' 
             }} 
        />

        {/* Connections Layer */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-0 overflow-visible">
          <defs>
             {/* Glow filter for cables */}
            <filter id="glow-line" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
            <linearGradient id="cable-gradient" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#22d3ee" />
              <stop offset="100%" stopColor="#a78bfa" />
            </linearGradient>
          </defs>
          
          {connections.map(conn => {
            const fromNode = nodes.find(n => n.id === conn.fromNodeId);
            const toNode = nodes.find(n => n.id === conn.toNodeId);
            if (!fromNode || !toNode) return null;

            const start = getPortPosition(fromNode, conn.fromPortId, false);
            const end = getPortPosition(toNode, conn.toPortId, true);
            const d = generatePath(start.x, start.y, end.x, end.y);

            return (
              <g key={conn.id}>
                {/* Outer Glow */}
                <path d={d} stroke="rgba(34, 211, 238, 0.2)" strokeWidth="6" fill="none" filter="url(#glow-line)" />
                {/* Inner Core */}
                <path d={d} stroke="url(#cable-gradient)" strokeWidth="2" fill="none" />
                {/* Moving Dash Animation */}
                <path d={d} stroke="white" strokeWidth="2" strokeDasharray="4, 100" fill="none" opacity="0.5">
                   <animate attributeName="stroke-dashoffset" from="104" to="0" dur="2s" repeatCount="indefinite" />
                </path>
              </g>
            );
          })}

          {connectionDrag.isDragging && connectionDrag.fromNodeId && (
            <path
              d={(() => {
                const node = nodes.find(n => n.id === connectionDrag.fromNodeId);
                if (!node) return '';
                const start = getPortPosition(node, connectionDrag.fromPortId!, false);
                return generatePath(start.x, start.y, connectionDrag.currentX, connectionDrag.currentY);
              })()}
              stroke="white"
              strokeWidth="2"
              strokeDasharray="5,5"
              fill="none"
              opacity="0.5"
            />
          )}
        </svg>

        {/* Nodes Layer */}
        {nodes.map(node => (
          <NodeComponent 
            key={node.id} 
            node={node} 
            isSelected={selectedNodeId === node.id}
            onMouseDown={handleNodeMouseDown}
            onPortMouseDown={handlePortMouseDown}
            scale={1}
          />
        ))}

        {/* Bottom Toolbar */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 glass-panel px-4 py-2 rounded-full flex gap-4 text-[10px] text-gray-400 font-mono tracking-tight pointer-events-auto">
          <div className="flex items-center gap-1"><span className="bg-white/10 px-1 rounded text-gray-200">Del</span> Delete</div>
          <div className="flex items-center gap-1"><span className="bg-white/10 px-1 rounded text-gray-200">⌘Z</span> Undo</div>
          <div className="flex items-center gap-1"><span className="bg-white/10 px-1 rounded text-gray-200">Shift</span> Multi-select</div>
          <div className="flex items-center gap-1"><span className="bg-white/10 px-1 rounded text-gray-200">Ctrl+Drag</span> Box select</div>
        </div>
        
        {/* Zoom Controls */}
        <div className="absolute bottom-6 left-6 glass-panel rounded-lg flex flex-col pointer-events-auto">
           <button className="p-2 hover:bg-white/10 text-gray-400 hover:text-white border-b border-white/5"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path></svg></button>
           <button className="p-2 hover:bg-white/10 text-gray-400 hover:text-white"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 12H4"></path></svg></button>
        </div>

      </div>

      <Inspector selectedNode={selectedNodeId ? nodes.find(n => n.id === selectedNodeId) || null : null} />
    </div>
  );
}

export default App;
